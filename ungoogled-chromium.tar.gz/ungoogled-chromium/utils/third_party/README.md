This directory contains third-party libraries used by build utilities.

Contents:

* [schema](//github.com/keleshev/schema)
    * For validating more sophisticated files such as INIs
